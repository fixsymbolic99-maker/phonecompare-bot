const dbManager = require('../database/database');
const db = dbManager.getDb();

class DatabaseService {
  // === المنتجات ===
  getProductByStore(storeId) {
    return new Promise((resolve, reject) => {
      db.get('SELECT * FROM products WHERE storeId = ?', [storeId], (err, row) => {
        if (err) reject(err);
        else resolve(row);
      });
    });
  }

  getProductById(id) {
    return new Promise((resolve, reject) => {
      db.get('SELECT * FROM products WHERE id = ?', [id], (err, row) => {
        if (err) reject(err);
        else resolve(row);
      });
    });
  }

  getAllProducts() {
    return new Promise((resolve, reject) => {
      db.all('SELECT * FROM products', (err, rows) => {
        if (err) reject(err);
        else resolve(rows);
      });
    });
  }

  async upsertProduct(storeId, name, price, url, currency = 'USD') {
    const existing = await this.getProductByStore(storeId);
    if (existing) {
      if (existing.price !== price) {
        await this.addHistory(existing.id, existing.price, existing.currency, 'update');
      }
      return new Promise((resolve, reject) => {
        db.run(
          'UPDATE products SET name = ?, price = ?, url = ?, currency = ?, lastUpdated = CURRENT_TIMESTAMP WHERE id = ?',
          [name, price, url, currency, existing.id],
          function(err) {
            if (err) reject(err);
            else resolve(existing.id);
          }
        );
      });
    } else {
      return new Promise((resolve, reject) => {
        db.run(
          'INSERT INTO products (storeId, name, price, currency, url) VALUES (?, ?, ?, ?, ?)',
          [storeId, name, price, currency, url],
          function(err) {
            if (err) reject(err);
            else resolve(this.lastID);
          }
        );
      });
    }
  }

  // === التاريخ ===
  addHistory(productId, price, currency, changeType = 'update') {
    return new Promise((resolve, reject) => {
      db.run(
        'INSERT INTO history (productId, price, currency, changeType) VALUES (?, ?, ?, ?)',
        [productId, price, currency, changeType],
        function(err) {
          if (err) reject(err);
          else resolve(this.lastID);
        }
      );
    });
  }

  getHistory(productId, limit = 10) {
    return new Promise((resolve, reject) => {
      db.all(
        'SELECT * FROM history WHERE productId = ? ORDER BY recordedAt DESC LIMIT ?',
        [productId, limit],
        (err, rows) => {
          if (err) reject(err);
          else resolve(rows);
        }
      );
    });
  }

  // === السجلات ===
  addLog(level, message) {
    return new Promise((resolve, reject) => {
      db.run(
        'INSERT INTO logs (level, message) VALUES (?, ?)',
        [level, message],
        function(err) {
          if (err) reject(err);
          else resolve(this.lastID);
        }
      );
    });
  }

  getLogs(limit = 100) {
    return new Promise((resolve, reject) => {
      db.all(
        'SELECT * FROM logs ORDER BY timestamp DESC LIMIT ?',
        [limit],
        (err, rows) => {
          if (err) reject(err);
          else resolve(rows);
        }
      );
    });
  }
}

module.exports = new DatabaseService();
